package fr.ca.cat.lib.libtomcatprobes;

import java.util.Map;

import org.apache.catalina.LifecycleEvent;
import org.apache.catalina.LifecycleListener;

public class TomcatListener implements LifecycleListener {

	private WebAppStatusManager webAppStatusManager = WebAppStatusManager.getInstance();

	@Override
	public void lifecycleEvent(LifecycleEvent arg0) {
		String event = arg0.getType();
		String webApp = arg0.getSource().toString();

		if (!event.equals("periodic")) {
			webAppStatusManager.getWebAppStatuses().put(webApp, event);

			for (String key : webAppStatusManager.getWebAppStatuses().keySet()) {
				System.out.println(key + " : " + webAppStatusManager.getWebAppStatuses().get(key));
			}
		}
	}

	public Map<String,String> istEventChange(){
		return WebAppStatusManager.getInstance().getWebAppStatuses();
	}
}
