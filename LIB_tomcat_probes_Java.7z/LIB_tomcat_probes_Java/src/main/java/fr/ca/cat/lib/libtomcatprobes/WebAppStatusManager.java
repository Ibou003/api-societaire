package fr.ca.cat.lib.libtomcatprobes;

import java.util.HashMap;
import java.util.Map;

public class WebAppStatusManager {

	private Map<String, String> webappStatuses; 
	private static WebAppStatusManager webAppStatusManager;
	
	private WebAppStatusManager() {
		this.webappStatuses = new HashMap<String, String>();
	}
	
	public static WebAppStatusManager getInstance() {
		if (webAppStatusManager == null) {
			webAppStatusManager = new WebAppStatusManager();
		}
		
		return webAppStatusManager;
	}
	
	public Map<String,String> getWebAppStatuses() {
		return this.webappStatuses;
	}
}
