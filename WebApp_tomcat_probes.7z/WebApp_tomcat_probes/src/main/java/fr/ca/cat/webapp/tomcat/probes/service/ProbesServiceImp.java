package fr.ca.cat.webapp.tomcat.probes.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import fr.ca.cat.lib.libtomcatprobes.TomcatListener;
import fr.ca.cat.webapp.tomcat.model.Application;

@Service
public class ProbesServiceImp implements ProbesService {

	@Autowired
	private TomcatListener tomcatListener;

	@Override
	public String getStatus() {
		Map<String, String> statusManagers = this.tomcatListener.istEventChange();
		if (statusManagers != null) {
			for (String key : statusManagers.keySet()) {
				if (!statusManagers.get(key).equals("after_start")) {
					System.out.println("statusManagers.get(key) : " + statusManagers.get(key));
					return "KO";
				}
			}
		}
		return "OK";
	}

	@Override
	public List <Application> getApplication() {
		Map<String, String> statusManagers = this.tomcatListener.istEventChange();
		ArrayList<Application> applications = new ArrayList<Application>();
		if (statusManagers != null) {
			for (String key : statusManagers.keySet()) {
				applications.add(new Application(key, statusManagers.get(key)));
			}
		}
		return applications;
	}
}
