package fr.ca.cat.webapp.tomcat.model;

public class Application {

	private String nomApplication;
	private String statusApplication;


	public Application(String nomApplication, String statusApplication) {
		super();
		this.nomApplication = nomApplication;
		this.statusApplication = statusApplication;
	}

	public String getNomApplication() {
		return nomApplication;
	}

	public void setNomApplication(String nomApplication) {
		this.nomApplication = nomApplication;
	}

	public String getStatusApplication() {
		return statusApplication;
	}

	public void setStatusApplication(String statusApplication) {
		this.statusApplication = statusApplication;
	}

}
