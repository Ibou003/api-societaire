package fr.ca.cat.webapp.tomcat.probes.service;

import java.util.List;

import fr.ca.cat.webapp.tomcat.model.Application;

public interface ProbesService {
	String getStatus();
	List <Application> getApplication();
}
