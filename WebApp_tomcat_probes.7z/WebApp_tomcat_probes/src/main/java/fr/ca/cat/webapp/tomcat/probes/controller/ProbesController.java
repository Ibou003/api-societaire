package fr.ca.cat.webapp.tomcat.probes.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import fr.ca.cat.webapp.tomcat.model.Application;
import fr.ca.cat.webapp.tomcat.probes.exception.ResourceNotFoundException;
import fr.ca.cat.webapp.tomcat.probes.service.ProbesService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

@RestController
@RequestMapping("/probes")
public class ProbesController {

	@Autowired
	private ProbesService probesService;

	// Ressource technique qui renvoie un code 200 si toutes les application
	// sont starting
	@GetMapping("/status")
	@ApiOperation(value = "${ProbesController.getStatus}")
	@ApiResponses(value = { @ApiResponse(code = 100, message = "100 is the message"),
			@ApiResponse(code = 200, message = "Sucessfull status ! ") })
	public String getStatus() {
		String status = this.probesService.getStatus();
		if (!status.equals("OK")) {
			throw new ResourceNotFoundException(status, "Provide correct Actor Id", null);
		}
		return status;
	}
	
	@GetMapping("/applications")
	@ApiOperation(value = "${ProbesController.getApplications}")
	@ApiResponses(value = { @ApiResponse(code = 100, message = "100 is the message"),
			@ApiResponse(code = 200, message = "Sucessfull Applications ! ") })
	public List<Application> getApplications() {
		return this.probesService.getApplication();
	}
}
