package fr.ca.cat.webapp.ihml.bff.utils;

import java.io.IOException;
import java.util.Objects;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;

public class AppUtils {

	public static String convertObjectToJsonString(Object obj) throws JsonProcessingException {
        if (Objects.isNull(obj)) {
            return null;
        }
        
        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(SerializationFeature.INDENT_OUTPUT);
        return mapper.writeValueAsString(obj);
	}
	
	public static String prettifyJsonString(String jsonString) throws IOException {
        if (Objects.isNull(jsonString)) {
            return null;
        }
        
        ObjectMapper mapper = new ObjectMapper();
        mapper.enable(SerializationFeature.INDENT_OUTPUT);
        Object json = mapper.readValue(jsonString, Object.class);
        
        return convertObjectToJsonString(json);
	}
}
