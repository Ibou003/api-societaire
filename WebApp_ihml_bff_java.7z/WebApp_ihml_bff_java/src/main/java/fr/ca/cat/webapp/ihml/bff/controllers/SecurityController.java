package fr.ca.cat.webapp.ihml.bff.controllers;

import java.io.IOException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;

import fr.ca.cat.webapp.ihml.bff.exceptions.ApiException;
import fr.ca.cat.webapp.ihml.bff.models.Session;
import fr.ca.cat.webapp.ihml.bff.models.User;
import fr.ca.cat.webapp.ihml.bff.services.SecurityService;

@RestController
@RequestMapping("/security")
public class SecurityController {

	@Value("${security.session.cookie}")
	private String sessionUserCookie;
	
	@Value("${security.session.domain}")
	private String domain;
	
	@Value("${security.userinfo.cookie}")
	private String userInfoCookie;
	
	@Autowired
	private SecurityService securityService;
	
	@GetMapping("/login")
	public ResponseEntity<Session> login(@RequestHeader (value = "Authorization") String code,
			@RequestHeader (value = "RedirectUrl") String redirectUrl,
			@RequestHeader (value = "SessionId") String sessionId) throws ApiException, IOException {
		
		Session session = this.securityService.login(code, redirectUrl, sessionId);
		HttpHeaders responseHeaders = new HttpHeaders();
	    responseHeaders.set("Set-Cookie", String.format("%s=%s; Domain=%s; path=/; Max-Age=28800", sessionUserCookie, session.getId(), domain));
		
	    return ResponseEntity.ok().headers(responseHeaders).body(session);
	}
	
	@GetMapping("/logout")
	public ResponseEntity<String> logout(@CookieValue(value = "SESSION_USER") String sessionId) throws ApiException, IOException {
		String response = this.securityService.logout(sessionId);	
	    return ResponseEntity.ok().body(response);
	}
	
	@GetMapping("/sessions")
	public List<Session> getSessions() {
		return this.securityService.getSessions();
	}
	
	@DeleteMapping("/sessions")
	public String clearSessions() throws IOException, ApiException {
		return this.securityService.clearSessions();
	}
	
	@GetMapping("/user")
	public ResponseEntity<User> getUserConnected(@CookieValue(value = "SESSION_USER") String sessionId) throws ApiException, IOException {
		User user = this.securityService.getUserConnected(sessionId);	
	    
		HttpHeaders responseHeaders = new HttpHeaders();
		ObjectMapper objectMapper = new ObjectMapper();		
	    responseHeaders.set("Set-Cookie", String.format("%s=%s; Domain=%s; path=/; Max-Age=28800", userInfoCookie, objectMapper.writeValueAsString(user), domain));

		return ResponseEntity.ok().headers(responseHeaders).body(user);
	}
	
	
}
