package fr.ca.cat.webapp.ihml.bff.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public class WeekSchedule {

	private String dayOfWeek;
	private OpeningHours[] openingHours;
	
	@JsonProperty(value = "day_of_week")
	public String getDayOfWeek() {
		return dayOfWeek;
	}
	
	@JsonProperty(value = "day_of_week")
	public void setDayOfWeek(String dayOfWeek) {
		this.dayOfWeek = dayOfWeek;
	}
	
	@JsonProperty(value = "opening_hours")
	public OpeningHours[] getOpeningHours() {
		return openingHours;
	}
	
	@JsonProperty(value = "opening_hours")
	public void setOpeningHours(OpeningHours[] openingHours) {
		this.openingHours = openingHours;
	}
}
