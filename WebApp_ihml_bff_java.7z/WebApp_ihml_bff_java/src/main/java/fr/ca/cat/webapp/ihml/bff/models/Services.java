package fr.ca.cat.webapp.ihml.bff.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Services {

	private boolean atm;
	private boolean automaticCashMachine;
	private boolean wheelChairAccess;
	private boolean carPark;
	private boolean exchangeCurrency;
	private String extraService1;
	private String extraService2;
	private String extraService3;
	
	@JsonProperty(value = "atm")
	public boolean isAtm() {
		return atm;
	}
	
	@JsonProperty(value = "atm")
	public void setAtm(boolean atm) {
		this.atm = atm;
	}
	
	@JsonProperty(value = "automatic_cash_machine")
	public boolean isAutomaticCashMachine() {
		return automaticCashMachine;
	}
	
	@JsonProperty(value = "automatic_cash_machine")
	public void setAutomaticCashMachine(boolean automaticCashMachine) {
		this.automaticCashMachine = automaticCashMachine;
	}
	
	@JsonProperty(value = "wheel_chair_access")
	public boolean isWheelChairAccess() {
		return wheelChairAccess;
	}
	
	@JsonProperty(value = "wheel_chair_access")
	public void setWheelChairAccess(boolean wheelChairAccess) {
		this.wheelChairAccess = wheelChairAccess;
	}
	
	@JsonProperty(value = "car_park")
	public boolean isCarPark() {
		return carPark;
	}
	
	@JsonProperty(value = "car_park")
	public void setCarPark(boolean carPark) {
		this.carPark = carPark;
	}
	
	@JsonProperty(value = "exchange_currency")
	public boolean isExchangeCurrency() {
		return exchangeCurrency;
	}
	
	@JsonProperty(value = "exchange_currency")
	public void setExchangeCurrency(boolean exchangeCurrency) {
		this.exchangeCurrency = exchangeCurrency;
	}
	
	@JsonProperty(value = "extra_service_1")
	public String getExtraService1() {
		return extraService1;
	}
	
	@JsonProperty(value = "extra_service_1")
	public void setExtraService1(String extraService1) {
		this.extraService1 = extraService1;
	}
	
	@JsonProperty(value = "extra_service_2")
	public String getExtraService2() {
		return extraService2;
	}
	
	@JsonProperty(value = "extra_service_2")
	public void setExtraService2(String extraService2) {
		this.extraService2 = extraService2;
	}
	
	@JsonProperty(value = "extra_service_3")
	public String getExtraService3() {
		return extraService3;
	}
	
	@JsonProperty(value = "extra_service_3")
	public void setExtraService3(String extraService3) {
		this.extraService3 = extraService3;
	}
	
}
