package fr.ca.cat.webapp.ihml.bff;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import fr.ca.cat.webapp.ihml.bff.services.HttpService;
import fr.ca.cat.webapp.ihml.bff.services.PlacesService;
import fr.ca.cat.webapp.ihml.bff.services.SecurityService;

@Configuration
@EnableWebMvc
@ComponentScan(basePackages = "fr.ca.cat.webapp.ihml.bff")
@PropertySource("classpath:application.properties")
public class ApplicationConfiguration {
	
	@Bean
	public SecurityService securityService() {
		return new SecurityService();
	}
	
	@Bean
	public PlacesService placesService() {
		return new PlacesService();
	}
	
	@Bean
	public HttpService httpService() {
		return new HttpService();
	}
}