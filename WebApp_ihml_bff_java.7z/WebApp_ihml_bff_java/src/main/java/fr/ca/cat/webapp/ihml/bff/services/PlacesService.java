package fr.ca.cat.webapp.ihml.bff.services;

import java.io.IOException;
import java.util.UUID;

import org.apache.http.HttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import com.fasterxml.jackson.databind.ObjectMapper;

import fr.ca.cat.webapp.ihml.bff.exceptions.ApiException;
import fr.ca.cat.webapp.ihml.bff.models.CR;
import fr.ca.cat.webapp.ihml.bff.models.DistributionEntity;
import fr.ca.cat.webapp.ihml.bff.models.Entity;
import fr.ca.cat.webapp.ihml.bff.models.Session;

public class PlacesService extends Service {

	@Autowired
	private HttpService httpService;
	
	@Value("${service.places}")
	private String placesUrl;
	
	@Value("${security.catsConsommateur}")
	private String catsConsommateur;
	
	public CR[] getCRList(String sessionId) throws IOException, ApiException {
		Session session = this.getSession(sessionId);
		
		HttpGet getCRRequest = new HttpGet(String.format("%s/regional_banks", placesUrl));
		
		// Set Headers
		getCRRequest.addHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_UTF8_VALUE);
		getCRRequest.addHeader(HttpHeaders.AUTHORIZATION, String.format("Bearer %s", session.getToken().getAccessToken()));
		getCRRequest.addHeader("correlationId", UUID.randomUUID().toString());
		getCRRequest.addHeader("cats_consommateur", catsConsommateur);
		
	    // Execute request
	    HttpResponse response = this.httpService.execute(getCRRequest);
		ObjectMapper objectMapper = new ObjectMapper();
		CR[] crs = objectMapper.readValue(EntityUtils.toString(response.getEntity()), CR[].class);
	    
		return crs;
	}
	
	public Entity[] getCREntities(String sessionId, int crdId) throws IOException, ApiException {
		Session session = this.getSession(sessionId);
		
		HttpGet getCRRequest = new HttpGet(String.format("%s/regional_banks/%d/cities_with_distribution_entities?type=1", placesUrl, crdId));
		
		// Set Headers
		getCRRequest.addHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_UTF8_VALUE);
		getCRRequest.addHeader(HttpHeaders.AUTHORIZATION, String.format("Bearer %s", session.getToken().getAccessToken()));
		getCRRequest.addHeader("correlationId", UUID.randomUUID().toString());
		getCRRequest.addHeader("cats_consommateur", catsConsommateur);
		
	    // Execute request
	    HttpResponse response = this.httpService.execute(getCRRequest);
		ObjectMapper objectMapper = new ObjectMapper();
		Entity[] entities = objectMapper.readValue(EntityUtils.toString(response.getEntity()), Entity[].class);
	    
		return entities;
	}
	
	public DistributionEntity[] getCRAgencesList(String sessionId, int crId, int zipCode) throws IOException, ApiException {
		Session session = this.getSession(sessionId);
		
		HttpGet getCRRequest = new HttpGet(String.format("%s/distribution_entities/search_by_city?regional_bank_id=%d&zip_code=%d", placesUrl, crId, zipCode));
		
		// Set Headers
		getCRRequest.addHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_UTF8_VALUE);
		getCRRequest.addHeader(HttpHeaders.AUTHORIZATION, String.format("Bearer %s", session.getToken().getAccessToken()));
		getCRRequest.addHeader("correlationId", UUID.randomUUID().toString());
		getCRRequest.addHeader("cats_consommateur", catsConsommateur);
		
	    // Execute request
	    HttpResponse response = this.httpService.execute(getCRRequest);
		ObjectMapper objectMapper = new ObjectMapper();
		DistributionEntity[] distributionEntities = objectMapper.readValue(EntityUtils.toString(response.getEntity()), DistributionEntity[].class);
	    
		return distributionEntities;
	}
}
