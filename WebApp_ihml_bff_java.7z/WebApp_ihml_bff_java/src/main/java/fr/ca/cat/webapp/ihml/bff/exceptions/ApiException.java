package fr.ca.cat.webapp.ihml.bff.exceptions;

public class ApiException extends Exception {
	
	private static final long serialVersionUID = 7813475184600026302L;
	private final int statusCode;
	
	public int getStatusCode() {
		return statusCode;
	}

	public ApiException(int code, String message) {
		super(message);
		this.statusCode = code;
	}
	
}
