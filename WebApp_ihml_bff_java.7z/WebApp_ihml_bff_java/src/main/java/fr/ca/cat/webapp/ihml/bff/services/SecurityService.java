package fr.ca.cat.webapp.ihml.bff.services;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.Objects;
import java.util.Optional;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;

import fr.ca.cat.most.util.log.MostLogger;
import fr.ca.cat.webapp.ihml.bff.exceptions.ApiException;
import fr.ca.cat.webapp.ihml.bff.models.OAuthToken;
import fr.ca.cat.webapp.ihml.bff.models.Session;
import fr.ca.cat.webapp.ihml.bff.models.User;

public class SecurityService {
	
	private MostLogger mostLogger = MostLogger.getLogger(SecurityService.class);
	
	@Value("${security.cliendID}")
	private String clientId;
	
	@Value("${security.secretID}")
	private String secretId;
	
	@Value("${security.catsConsommateur}")
	private String catsConsommateur;
	
	@Value("${security.catsConsommateurorigine}")
	private String catsConsommateurorigine;
	
	@Value("${security.catsCanal}")
	private String catsCanal;
	
	@Value("${service.auc9}")
	private String auc9Url;
		
	@Autowired
	protected HttpService httpService;
	
	private List<Session> sessions;
	
	public SecurityService() {
		this.sessions = new ArrayList<>();
	}
	
	public List<Session> getSessions() {
		mostLogger.debugInfo("Getting all sessions");
		return this.sessions;
	}
	
	public String clearSessions() throws IOException, ApiException {
		mostLogger.debugInfo("Clearing all sessions");
		for (Session session : this.sessions) {
			this.revokeSession(session.getId());
		}
		
		this.sessions.clear();
		mostLogger.debugInfo("All sessions cleared");
		return "All sessions cleared";
	}
	
	public Session login(String code, String redirectUrl, String sessionId) throws ApiException, IOException {
		mostLogger.debugInfo("Login new session " + sessionId);
		Session session = new Session();
		session.setId(sessionId);
		
		HttpPost postTokenRequest = new HttpPost(String.format("%s/openid/token", auc9Url));
		
		// Set Headers
		postTokenRequest.addHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_FORM_URLENCODED_VALUE);
		postTokenRequest.addHeader(HttpHeaders.AUTHORIZATION, this.getAuthorizationToken());
		postTokenRequest.addHeader("correlationId", sessionId);
		postTokenRequest.addHeader("cats_consommateur", catsConsommateur);
		postTokenRequest.addHeader("cats_consommateurorigine", catsConsommateurorigine);
		postTokenRequest.addHeader("cats_canal", catsCanal);
		
		// Set Body
		List<NameValuePair> params = new ArrayList<>();
	    params.add(new BasicNameValuePair("grant_type", "authorization_code"));
	    params.add(new BasicNameValuePair("scope", "openid"));
	    params.add(new BasicNameValuePair("code", code));
	    params.add(new BasicNameValuePair("redirect_uri", redirectUrl));
	    postTokenRequest.setEntity(new UrlEncodedFormEntity(params));
	    
	    // Execute request
	    HttpResponse response = this.httpService.execute(postTokenRequest);
	    
	    // Parse response to OAuhtToken
		ObjectMapper objectMapper = new ObjectMapper();
		OAuthToken oAuthToken = objectMapper.readValue(EntityUtils.toString(response.getEntity()), OAuthToken.class);
		oAuthToken.setUser(this.getUserFromTokenId(oAuthToken.getIdToken()));
		session.setToken(oAuthToken);
		session.setUser(oAuthToken.getUser());
		
		sessions.add(session);
		
		mostLogger.debugInfo("Login session " + sessionId + " done");
		return session;
	}
	
	public String logout(String sessionId) throws IOException, ApiException {
		mostLogger.debugInfo("Logout session " + sessionId);
		Session session = this.revokeSession(sessionId);		
		sessions.remove(session);
		mostLogger.debugInfo("Logout session " + sessionId + " done");
		return "revoked";
	}
	
	public Session revokeSession(String sessionId) throws IOException, ApiException {
		mostLogger.debugInfo("Revoking session " + sessionId);
		Session session = this.getSession(sessionId);
		
		if (Objects.nonNull(session)) {
			
			HttpPost postTokenRequest = new HttpPost(String.format("%s/openid/revoke", auc9Url));
			
			// Set Headers
			postTokenRequest.addHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_FORM_URLENCODED_VALUE);
			postTokenRequest.addHeader(HttpHeaders.AUTHORIZATION, this.getAuthorizationToken());
			postTokenRequest.addHeader("correlationId", sessionId);
			postTokenRequest.addHeader("cats_consommateur", catsConsommateur);
			postTokenRequest.addHeader("cats_consommateurorigine", catsConsommateurorigine);
			postTokenRequest.addHeader("cats_canal", catsCanal);
			
			// Set Body
			List<NameValuePair> params = new ArrayList<>();
		    params.add(new BasicNameValuePair("token", session.getToken().getRefreshToken()));
		    postTokenRequest.setEntity(new UrlEncodedFormEntity(params));
		    
		    // Execute request
		    this.httpService.execute(postTokenRequest);	
		    
		    mostLogger.debugInfo("Revoking session " + sessionId + " done");
			return session;
		} else {
			session = new Session();
			session.setId(sessionId);
			return session;
		}
	}
	
	public Session refreshToken(String sessionId) throws ApiException, IOException {
		mostLogger.debugInfo("Refreshing token session " + sessionId);
		Session session = this.getSession(sessionId);		
		
		if (Objects.nonNull(session)) {

			HttpPost postTokenRequest = new HttpPost(String.format("%s/openid/token", auc9Url));
			
			// Set Headers
			postTokenRequest.addHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_FORM_URLENCODED_VALUE);
			postTokenRequest.addHeader(HttpHeaders.AUTHORIZATION, this.getAuthorizationToken());
			postTokenRequest.addHeader("correlationId", sessionId);
			postTokenRequest.addHeader("cats_consommateur", catsConsommateur);
			postTokenRequest.addHeader("cats_consommateurorigine", catsConsommateurorigine);
			postTokenRequest.addHeader("cats_canal", catsCanal);
			
			// Set Body
			List<NameValuePair> params = new ArrayList<>();
			params.add(new BasicNameValuePair("grant_type", "refresh_token"));
			params.add(new BasicNameValuePair("scope", "openid functionnal_posts"));
		    params.add(new BasicNameValuePair("refresh_token", session.getToken().getRefreshToken()));
		    postTokenRequest.setEntity(new UrlEncodedFormEntity(params));
		    
		    // Execute request
		    this.httpService.execute(postTokenRequest);	
		    
		    mostLogger.debugInfo("Refreshing token session " + sessionId + " done");
			return session;
		} else {
			throw new ApiException(404, "Session " + sessionId + " not found");
		}
	}
	
	public User getUserConnected(String sessionId) throws ApiException {
		mostLogger.debugInfo("Getting user connected with session " + sessionId);
		Session session = this.getSession(sessionId);
		
		if (Objects.nonNull(session)) {
			mostLogger.debugInfo("Getting user connected with session " + sessionId + "done");
			return session.getUser();
		} else {
			throw new ApiException(404, "User with session " + sessionId + " not found");
		}
	}
	
	private User getUserFromTokenId(String tokenId) {
		User user = new User();
		
		String tokenIdSplit = tokenId.split("\\.")[1];
		String tokenIdDecoded = new String(Base64.getDecoder().decode(tokenIdSplit.getBytes()));
		
		JsonElement json = JsonParser.parseString(tokenIdDecoded);
		String sub = json.getAsJsonObject().get("sub").getAsString();
		
		user.setId(sub);
		return user;
	}
	
	public Session getSession(String sessionId) {
		Optional<Session> session = sessions.stream().filter(sess -> sess.getId().equals(sessionId)).findFirst();		
		return session.isPresent() ? session.get() : null ;
	}
	
	private String getAuthorizationToken() {
		String base64Authorization = Base64.getEncoder().encodeToString((String.format("%s:%s", clientId, secretId).getBytes()));
		return String.format("Basic %s", base64Authorization);
	}
}
