package fr.ca.cat.webapp.ihml.bff.models;

public class Session {

	private String id;
	private OAuthToken token;
	private User user;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public OAuthToken getToken() {
		return token;
	}
	public void setToken(OAuthToken token) {
		this.token = token;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
}
