package fr.ca.cat.webapp.ihml.bff.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public class DistributionEntity {
	
	private String id;
	private String name;
	private String regionalBankId;
	private int type;
	private Services services;
	private Address address;
	private WeekSchedule[] weekSchedule;
	private Coordinates coordinates;
	private Market market;
	private Contact contact;
	private String idEdsBanalise;
	
	@JsonProperty(value = "id")
	public String getId() {
		return id;
	}
	
	@JsonProperty(value = "id")
	public void setId(String id) {
		this.id = id;
	}
	
	@JsonProperty(value = "name")
	public String getName() {
		return name;
	}
	
	@JsonProperty(value = "name")
	public void setName(String name) {
		this.name = name;
	}
	
	@JsonProperty(value = "regional_bank_id")
	public String getRegionalBankId() {
		return regionalBankId;
	}
	
	@JsonProperty(value = "regional_bank_id")
	public void setRegionalBankId(String regionalBankId) {
		this.regionalBankId = regionalBankId;
	}
	
	@JsonProperty(value = "type")
	public int getType() {
		return type;
	}
	
	@JsonProperty(value = "type")
	public void setType(int type) {
		this.type = type;
	}
	
	@JsonProperty(value = "services")
	public Services getServices() {
		return services;
	}
	
	@JsonProperty(value = "services")
	public void setServices(Services services) {
		this.services = services;
	}
	
	@JsonProperty(value = "address")
	public Address getAddress() {
		return address;
	}
	
	@JsonProperty(value = "address")
	public void setAddress(Address address) {
		this.address = address;
	}
	
	@JsonProperty(value = "week_schedule")
	public WeekSchedule[] getWeekSchedule() {
		return weekSchedule;
	}
	
	@JsonProperty(value = "week_schedule")
	public void setWeekSchedule(WeekSchedule[] weekSchedule) {
		this.weekSchedule = weekSchedule;
	}
	
	@JsonProperty(value = "coordinates")
	public Coordinates getCoordinates() {
		return coordinates;
	}
	
	@JsonProperty(value = "coordinates")
	public void setCoordinates(Coordinates coordinates) {
		this.coordinates = coordinates;
	}
	
	@JsonProperty(value = "market")
	public Market getMarket() {
		return market;
	}
	
	@JsonProperty(value = "market")
	public void setMarket(Market market) {
		this.market = market;
	}
	
	@JsonProperty(value = "contact")
	public Contact getContact() {
		return contact;
	}
	
	@JsonProperty(value = "contact")
	public void setContact(Contact contact) {
		this.contact = contact;
	}
	
	@JsonProperty(value = "id_eds_banalise")
	public String getIdEdsBanalise() {
		return idEdsBanalise;
	}
	
	@JsonProperty(value = "id_eds_banalise")
	public void setIdEdsBanalise(String idEdsBanalise) {
		this.idEdsBanalise = idEdsBanalise;
	}

}
