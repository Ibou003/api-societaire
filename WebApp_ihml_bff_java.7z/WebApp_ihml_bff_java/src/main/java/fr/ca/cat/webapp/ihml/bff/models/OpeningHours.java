package fr.ca.cat.webapp.ihml.bff.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public class OpeningHours {

	private String opening;
	private String closing;
	
	@JsonProperty(value = "opening")
	public String getOpening() {
		return opening;
	}
	
	@JsonProperty(value = "opening")
	public void setOpening(String opening) {
		this.opening = opening;
	}
	
	@JsonProperty(value = "closing")
	public String getClosing() {
		return closing;
	}
	
	@JsonProperty(value = "closing")
	public void setClosing(String closing) {
		this.closing = closing;
	}
}
