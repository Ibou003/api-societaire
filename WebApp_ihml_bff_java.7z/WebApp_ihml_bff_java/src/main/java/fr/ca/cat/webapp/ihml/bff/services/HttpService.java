package fr.ca.cat.webapp.ihml.bff.services;

import java.io.IOException;

import javax.annotation.PreDestroy;

import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpRequestBase;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import fr.ca.cat.webapp.ihml.bff.exceptions.ApiException;
import fr.ca.cat.webapp.ihml.bff.utils.AppUtils;

public class HttpService {

	private HttpClient httpClient;
	
	public HttpService() {
		this.httpClient = HttpClients.createDefault();
	}

	public HttpClient getHttpClient() {
		return httpClient;
	}
	
	@PreDestroy
	public void teardown() {
		this.httpClient = null;
	}
	
	public HttpResponse execute(HttpRequestBase request) throws IOException, ApiException {
		HttpResponse response = this.httpClient.execute(request);
		
	    if (response.getStatusLine().getStatusCode() != 200) {
			throw new ApiException(response.getStatusLine().getStatusCode() , AppUtils.prettifyJsonString(EntityUtils.toString(response.getEntity())));
		} else { 
			return response;
		}
	}
}
