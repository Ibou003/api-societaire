package fr.ca.cat.webapp.ihml.bff.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Coordinates {

	private String latitude;
	private String longitude;
	
	@JsonProperty(value = "latitude")
	public String getLatitude() {
		return latitude;
	}
	
	@JsonProperty(value = "latitude")
	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}
	
	@JsonProperty(value = "longitude")
	public String getLongitude() {
		return longitude;
	}
	
	@JsonProperty(value = "longitude")
	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}
}
