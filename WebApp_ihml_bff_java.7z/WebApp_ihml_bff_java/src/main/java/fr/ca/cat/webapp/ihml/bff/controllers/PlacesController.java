package fr.ca.cat.webapp.ihml.bff.controllers;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import fr.ca.cat.webapp.ihml.bff.exceptions.ApiException;
import fr.ca.cat.webapp.ihml.bff.models.CR;
import fr.ca.cat.webapp.ihml.bff.models.DistributionEntity;
import fr.ca.cat.webapp.ihml.bff.models.Entity;
import fr.ca.cat.webapp.ihml.bff.services.PlacesService;

@RestController
@RequestMapping("/places")
public class PlacesController {

	@Autowired
	private PlacesService placesService;
	
	 @GetMapping("/regional_banks")
	 public ResponseEntity<CR[]> getPlaces(@CookieValue(value = "SESSION_USER") String sessionId) throws IOException, ApiException {
		 CR[] crs = this.placesService.getCRList(sessionId);
		 return ResponseEntity.ok().body(crs);
	 }
	 
	 @GetMapping("/regional_banks/{crId}/cities_with_distribution_entities")
	 public ResponseEntity<Entity[]> getCREntities(@CookieValue(value = "SESSION_USER") String sessionId, @PathVariable("crId") int crId) throws IOException, ApiException {
		 Entity[] entities = this.placesService.getCREntities(sessionId, crId);
		 return ResponseEntity.ok().body(entities);
	 }
	 
	 @GetMapping("/distribution_entities/search_by_city/{crId}/{zipCode}")
	 public ResponseEntity<DistributionEntity[]> getCRAgencesList(@CookieValue(value = "SESSION_USER") String sessionId, @PathVariable("crId") int crId, @PathVariable ("zipCode") int zipCode) throws IOException, ApiException {
		 DistributionEntity[] distributionEntities = this.placesService.getCRAgencesList(sessionId, crId, zipCode);
		 return ResponseEntity.ok().body(distributionEntities);
	 }
}
