package fr.ca.cat.webapp.ihml.bff.filters;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.filter.OncePerRequestFilter;

import fr.ca.cat.webapp.ihml.bff.exceptions.ApiException;
import fr.ca.cat.webapp.ihml.bff.models.ErrorResponse;
import fr.ca.cat.webapp.ihml.bff.utils.AppUtils;

public class ErrorHandlerFilter extends OncePerRequestFilter {

	public void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		try {
			chain.doFilter(request, response);
        } catch (Exception e) {

            ErrorResponse errorResponse = new ErrorResponse();
            errorResponse.setStatus(500);
            
            String message = e.getMessage();
            
            if (e.getCause() instanceof ApiException) {
            	ApiException ex = (ApiException) e.getCause(); 
            	message = ex.getMessage();
            	errorResponse.setStatus(ex.getStatusCode());
            }
            
            errorResponse.setMessage(message);

            response.setStatus(errorResponse.getStatus());
            response.setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
            response.getWriter().write(AppUtils.convertObjectToJsonString(errorResponse));
        }		
	}
}
