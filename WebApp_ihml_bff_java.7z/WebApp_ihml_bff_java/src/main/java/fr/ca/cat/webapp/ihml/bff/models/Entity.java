package fr.ca.cat.webapp.ihml.bff.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Entity {
    private String cityName;
    private String zipCode;
    
    @JsonProperty(value = "city_name")
	public String getCityName() {
		return cityName;
	}
	
    @JsonProperty(value = "city_name")
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	
    @JsonProperty(value = "zip_code")
	public String getZipCode() {
		return zipCode;
	}
	
    @JsonProperty(value = "zip_code")
	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}
    
}
