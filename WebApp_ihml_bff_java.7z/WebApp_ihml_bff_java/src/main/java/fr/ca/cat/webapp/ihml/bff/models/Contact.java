package fr.ca.cat.webapp.ihml.bff.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Contact {

	private String emailAddress;
	private String phoneNumber;
	private String phoneFee;
	private String fax;
	
	@JsonProperty(value = "email_address")
	public String getEmailAddress() {
		return emailAddress;
	}
	
	@JsonProperty(value = "email_address")
	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}
	
	@JsonProperty(value = "phone_number")
	public String getPhoneNumber() {
		return phoneNumber;
	}
	
	@JsonProperty(value = "phone_number")
	public void setPhoneNumber(String phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	@JsonProperty(value = "phone_fee")
	public String getPhoneFee() {
		return phoneFee;
	}
	
	@JsonProperty(value = "phone_fee")
	public void setPhoneFee(String phoneFee) {
		this.phoneFee = phoneFee;
	}
	
	@JsonProperty(value = "fax")
	public String getFax() {
		return fax;
	}
	
	@JsonProperty(value = "fax")
	public void setFax(String fax) {
		this.fax = fax;
	}
}
