package fr.ca.cat.webapp.ihml.bff.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public class CR {
	private String regionalBankId;
	private String regionalBankName;
	
	@JsonProperty(value = "regional_bank_id")
	public String getRegionalBankId() {
		return regionalBankId;
	}
	
	@JsonProperty(value = "regional_bank_id")
	public void setRegionalBankId(String regionalBankId) {
		this.regionalBankId = regionalBankId;
	}
	
	@JsonProperty(value = "regional_bank_name")
	public String getRegionalBankName() {
		return regionalBankName;
	}
	
	@JsonProperty(value = "regional_bank_name")
	public void setRegionalBankName(String regionalBankName) {
		this.regionalBankName = regionalBankName;
	}
	
	
}
