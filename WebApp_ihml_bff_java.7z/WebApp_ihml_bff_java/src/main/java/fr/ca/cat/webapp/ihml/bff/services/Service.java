package fr.ca.cat.webapp.ihml.bff.services;

import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;

import fr.ca.cat.webapp.ihml.bff.exceptions.ApiException;
import fr.ca.cat.webapp.ihml.bff.models.Session;

public class Service {
	
	@Autowired
	private SecurityService securityService;
	
	public Session getSession(String sessionId) throws ApiException {
		Session session = this.securityService.getSession(sessionId);
		
		if (Objects.isNull(session)) {
			throw new ApiException(401, "Invalid credentials or session token");
		} else {
			return session;
		}
	}
}
