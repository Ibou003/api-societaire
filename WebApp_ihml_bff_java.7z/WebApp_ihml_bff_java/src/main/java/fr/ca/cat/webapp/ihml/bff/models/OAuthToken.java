package fr.ca.cat.webapp.ihml.bff.models;

import java.time.LocalDateTime;
import java.time.ZoneId;

import com.fasterxml.jackson.annotation.JsonProperty;

public class OAuthToken {
	private long expirationDate;
	private String accessToken;
	private String type;
	private String idToken;
	private String refreshToken;
	private User user;
	
	@JsonProperty("expirationDate")
	public long getExpirationDate() {
		return expirationDate;
	}
	
	@JsonProperty("expires_in")
	public void setExpirationDate(long expirationDate) {
		LocalDateTime localDatetime = LocalDateTime.now().plusSeconds(expirationDate);
		this.expirationDate = localDatetime.atZone(ZoneId.systemDefault()).toInstant().toEpochMilli();
	}
	
	@JsonProperty("access_token")
	public String getAccessToken() {
		return accessToken;
	}
	
	@JsonProperty("access_token")
	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}
	
	@JsonProperty("type")
	public String getType() {
		return type;
	}
	
	@JsonProperty("token_type")
	public void setType(String type) {
		this.type = type;
	}
	
	@JsonProperty("id_token")
	public String getIdToken() {
		return idToken;
	}
	
	@JsonProperty("id_token")
	public void setIdToken(String idToken) {
		this.idToken = idToken;
	}
	
	@JsonProperty("refresh_token")
	public String getRefreshToken() {
		return refreshToken;
	}
	
	@JsonProperty("refresh_token")
	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}
	
	public User getUser() {
		return user;
	}
	
	public void setUser(User user) {
		this.user = user;
	}
	
}
