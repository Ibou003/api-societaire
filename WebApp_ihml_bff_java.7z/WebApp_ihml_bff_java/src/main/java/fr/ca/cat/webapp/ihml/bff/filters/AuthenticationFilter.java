package fr.ca.cat.webapp.ihml.bff.filters;

import java.io.IOException;
import java.time.Instant;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.TimeZone;
import java.util.regex.Pattern;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import fr.ca.cat.most.util.log.MostLogger;
import fr.ca.cat.webapp.ihml.bff.exceptions.ApiException;
import fr.ca.cat.webapp.ihml.bff.models.ErrorResponse;
import fr.ca.cat.webapp.ihml.bff.models.Session;
import fr.ca.cat.webapp.ihml.bff.services.SecurityService;
import fr.ca.cat.webapp.ihml.bff.utils.AppUtils;

public class AuthenticationFilter implements Filter {
	
	@Autowired
	private SecurityService securityService;
	
	private MostLogger mostLogger = MostLogger.getLogger(AuthenticationFilter.class);
	private List<String> apiTokenUrls;
	private List<String> adminTokenUrls;

	@Override
	public void init(FilterConfig filterConfig)  throws ServletException  {
		this.apiTokenUrls = Arrays.asList("\\/places\\/.*");
		this.adminTokenUrls = Arrays.asList("\\/security\\/sessions");		
		SpringBeanAutowiringSupport.processInjectionBasedOnServletContext(this, filterConfig.getServletContext());
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		HttpServletRequest httpServletRequest = (HttpServletRequest) request;
		HttpServletResponse httpServletResponse = (HttpServletResponse) response;
		String requestUrl = httpServletRequest.getPathInfo();
		
		if (matchPatternUrls(requestUrl, apiTokenUrls)) {
			mostLogger.debugInfo("Api Token Authentication");
			
			// Get Session Id from Cookie
			List<Cookie> requestCookies = Arrays.asList(httpServletRequest.getCookies());
			
			Optional<Cookie> sessionUserCookie = requestCookies.stream().filter(cookie -> cookie.getName().equals("SESSION_USER")).findFirst(); 
		
			if (sessionUserCookie.isPresent()) {
				String sessionId = sessionUserCookie.get().getValue();
				
				Session session = this.securityService.getSession(sessionId);
				
				if (Objects.nonNull(session)) {
					LocalDateTime timeoutSession = LocalDateTime.now().plusHours(2);
					LocalDateTime now = LocalDateTime.now();
					if (now.isBefore(LocalDateTime.ofInstant(Instant.ofEpochMilli(session.getToken().getExpirationDate()), TimeZone.getDefault().toZoneId()))) {
						// Session valid
						chain.doFilter(request, response);
					} else if (now.isBefore(timeoutSession)) {
						// Time out not reached. Refresh Token
						try {
							this.securityService.refreshToken(sessionId);
							chain.doFilter(request, response);
						} catch (ApiException e) {
							rejectResponse(e.getStatusCode(), e.getMessage(), httpServletResponse);
						}
					} else {
						try {
							this.securityService.logout(sessionId);
							rejectResponse(401, "Session expired", httpServletResponse);
						} catch (ApiException e) {
							rejectResponse(e.getStatusCode(), e.getMessage(), httpServletResponse);
						}
					}
				} else {
					rejectResponse(401, "Invalid credentials or session token", httpServletResponse);
				}				
				
			} else {
				rejectResponse(401, "Invalid credentials or session token", httpServletResponse);
			}
		
		} else if (matchPatternUrls(requestUrl, adminTokenUrls)) {
			mostLogger.debugInfo("Admin Authentication");
			
			// R�cup�ration header authorization
			String authorizationHeader = httpServletRequest.getHeader(HttpHeaders.AUTHORIZATION);			
			
			if (Objects.nonNull(authorizationHeader)) {
				String clientSecretB64 = authorizationHeader.split(" ")[1];
				String[] clientSecretSplit = new String(Base64.getDecoder().decode(clientSecretB64.getBytes())).split(":");
				String login = clientSecretSplit[0];
				String pwd = clientSecretSplit[1];
				
				if (Objects.isNull(login) || Objects.isNull(pwd)) {
					rejectResponse(401, "Invalid credentials or session token", httpServletResponse);
				} else if (!login.equals("admin") || !pwd.equals("admin")) {
					rejectResponse(401, "Invalid credentials or session token", httpServletResponse);
				} else {
					chain.doFilter(request, response);
				}
			} else {
				rejectResponse(401, "Authorization header doesn't exist", httpServletResponse);
			}
		} else {
			mostLogger.debugInfo("No Authentication");
			chain.doFilter(request, response);
		}
	}

	@Override
	public void destroy() {}
	
	private boolean matchPatternUrls(String url, List<String> patterns) {
		return patterns.stream().filter(pattern -> Pattern.matches(pattern, url)).count() > 0;
	}
	
	private void rejectResponse(int statusCode, String message, HttpServletResponse response) throws IOException {
        ErrorResponse errorResponse = new ErrorResponse();
        errorResponse.setStatus(statusCode);
        errorResponse.setMessage(message);
        response.setStatus(errorResponse.getStatus());
        response.setHeader(HttpHeaders.CONTENT_TYPE, MediaType.APPLICATION_JSON_VALUE);
        response.getWriter().write(AppUtils.convertObjectToJsonString(errorResponse));
	}

}
