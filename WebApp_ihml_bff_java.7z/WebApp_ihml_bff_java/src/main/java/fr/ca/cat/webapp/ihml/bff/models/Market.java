package fr.ca.cat.webapp.ihml.bff.models;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Market {
	
	private boolean generalPublic;
	private boolean privateBanking;
	private boolean pro;
	private boolean farmer;
	private boolean association;
	private boolean enterprise;
	private boolean publicCollectivity;
	
	@JsonProperty(value = "general_public")
	public boolean isGeneralPublic() {
		return generalPublic;
	}
	
	@JsonProperty(value = "general_public")
	public void setGeneralPublic(boolean generalPublic) {
		this.generalPublic = generalPublic;
	}
	
	@JsonProperty(value = "private_banking")
	public boolean isPrivateBanking() {
		return privateBanking;
	}
	
	@JsonProperty(value = "private_banking")
	public void setPrivateBanking(boolean privateBanking) {
		this.privateBanking = privateBanking;
	}
	
	@JsonProperty(value = "pro")
	public boolean isPro() {
		return pro;
	}
	
	@JsonProperty(value = "pro")
	public void setPro(boolean pro) {
		this.pro = pro;
	}
	
	@JsonProperty(value = "farmer")
	public boolean isFarmer() {
		return farmer;
	}
	
	@JsonProperty(value = "farmer")
	public void setFarmer(boolean farmer) {
		this.farmer = farmer;
	}
	
	@JsonProperty(value = "association")
	public boolean isAssociation() {
		return association;
	}
	
	@JsonProperty(value = "association")
	public void setAssociation(boolean association) {
		this.association = association;
	}
	
	@JsonProperty(value = "enterprise")
	public boolean isEnterprise() {
		return enterprise;
	}
	
	@JsonProperty(value = "enterprise")
	public void setEnterprise(boolean enterprise) {
		this.enterprise = enterprise;
	}
	
	@JsonProperty(value = "public_collectivity")
	public boolean isPublicCollectivity() {
		return publicCollectivity;
	}
	
	@JsonProperty(value = "public_collectivity")
	public void setPublicCollectivity(boolean publicCollectivity) {
		this.publicCollectivity = publicCollectivity;
	}
}
